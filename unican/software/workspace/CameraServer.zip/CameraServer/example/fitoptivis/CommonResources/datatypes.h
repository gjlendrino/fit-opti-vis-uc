#ifndef datatypes
#define datatypes

#include "datatypes/imageData.h"

#endif
