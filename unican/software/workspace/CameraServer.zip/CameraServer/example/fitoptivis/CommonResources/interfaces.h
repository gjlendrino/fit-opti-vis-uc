#ifndef interfaces
#define interfaces

#include "derived_interfaces.h"

#include "interfaces/I_Image.h"
#include "interfaces/I_Image_Remote.h"

#endif
