#include "I_Image.h"

void I_Image::get_image(imageData &data){};

I_Image::~I_Image(){};
