#include "../fitoptivis.h"

RIEREG_Library(libFitoptivis);
RIEREG_ComponentType("libFitoptivis",System,"");
RIEREG_ComponentType("libFitoptivis",Camera,"");
RIEREG_ComponentType("libFitoptivis",Display,"");

#define component_generated_cpp
#include "generated/component.cpp"
