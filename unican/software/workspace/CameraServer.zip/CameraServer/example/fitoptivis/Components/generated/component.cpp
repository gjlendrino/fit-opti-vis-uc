#ifdef component_generated_cpp

RIEREG_ComponentType("libFitoptivis",remoteSystem,"");
RIEREG_ComponentType( "libFitoptivis" , Camera_Remote , "Camera" );
RIEREG_ComponentType( "libFitoptivis" , Camera_RemoteServer , "Camera" );


#endif
