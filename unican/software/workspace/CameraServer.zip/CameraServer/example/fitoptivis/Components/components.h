#ifndef components_h
#define components_h

#include "system.h"

#include "Camera.h"
#include "Display.h"

#include "generated/component.h"

#endif
