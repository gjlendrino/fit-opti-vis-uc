this->assignID("mainSystem");
comp1_Camera.assignID("Comp1_base");
inst1_Camera.setName("Comp1_base");
RIE_ASSIGN_COMP2INSTANCE(comp1_Camera, inst1_Camera);
comp1_Camera.registerComponent();


