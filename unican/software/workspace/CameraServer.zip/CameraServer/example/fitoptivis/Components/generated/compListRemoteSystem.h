Camera_RemoteServer 	comp1_Camera;
RIEInstance 	inst1_Camera;

