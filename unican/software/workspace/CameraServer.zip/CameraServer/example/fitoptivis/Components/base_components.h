#ifndef base_components_h
#define base_components_h

#include "Camera.h"
#include "Display.h"

#endif
