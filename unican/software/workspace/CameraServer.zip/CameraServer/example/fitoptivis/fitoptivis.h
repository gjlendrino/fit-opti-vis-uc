#ifndef fitoptivis
#define fitoptivis

#include "fitoptivis_base.h"
#include "../fitoptivis/Components/components.h"

#define IPRemoteServer "192.168.0.103"

#endif
